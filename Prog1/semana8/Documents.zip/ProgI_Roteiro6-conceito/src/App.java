public class App {
    public static void main(String[] args) {
        Aluno a1 = new Aluno();
        double notaA1 = a1.media(7, 4, 8);
        
        AlunoPosGraduacao apos1 = new AlunoPosGraduacao();
        double notaApos1 = apos1.media(7, 4);

        System.out.println("A média do aluno é: " + notaA1);

    }
}
