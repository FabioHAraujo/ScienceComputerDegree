public class AssistenteAdm extends Assistente{
    double adicionalNoturno;
    String turno;    

    public AssistenteAdm (String nome, String endereco, String sexo, String dataContratacao, double salario, String especializacao, String turno) {
        super(nome, endereco, sexo, dataContratacao, salario, especializacao);
        this.turno = turno;
    }
}
