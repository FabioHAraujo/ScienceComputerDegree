public class Gerente extends Funcionario {
    int NivelAcesso;

    public Gerente(String nome, String endereco, String sexo, String dataContratacao, double salario, int nivelAcesso) {
        super(nome, endereco, sexo, dataContratacao, salario);
        NivelAcesso = nivelAcesso;
    }
}
