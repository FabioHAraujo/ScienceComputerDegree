public class Funcionario{
    String nome;
    String endereco;
    String sexo;
    String dataContratacao;
    double salario;

    public Funcionario(String nome, String endereco, String sexo, String dataContratacao, double salario) {
        this.nome = nome;
        this.endereco = endereco;
        this.sexo = sexo;
        this.dataContratacao = dataContratacao;
        this.salario = salario;
    }
}