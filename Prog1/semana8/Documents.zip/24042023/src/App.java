import javax.swing.JOptionPane;

public class App {
    public static void main(String[] args) {
        String tempStr = JOptionPane.showInputDialog(null, "Vamos cadastrar um Funcionario, qual a função deste funcionario? (Gerente, Assistente Administrativo ou Assistente Tecnico)");
        if (tempStr.contains("Gerente")) {
            String nome = JOptionPane.showInputDialog(null, "Qual o nome do Gerente?");
            String endereco = JOptionPane.showInputDialog(null, "Qual o endereço do Gerente?");
            String sexo = JOptionPane.showInputDialog(null, "Qual o sexo do Gerente?");
            String dataContratacao = JOptionPane.showInputDialog(null, "Qual a data de contratação do Gerente?");
            double salario = Double.parseDouble(JOptionPane.showInputDialog(null, "Qual o salario do Gerente?"));
            int nivelAcesso = Integer.parseInt(JOptionPane.showInputDialog(null, "Qual o nivel de acesso do Gerente?"));
            Gerente gerente = new Gerente(nome, endereco, sexo, dataContratacao, salario, nivelAcesso);
            JOptionPane.showMessageDialog(null, "Gerente cadastrado com sucesso!");
            JOptionPane.showMessageDialog(null, "Nome: " + gerente.nome + "\nEndereço: " + gerente.endereco + "\nSexo: " + gerente.sexo + "\nData de contratação: " + gerente.dataContratacao + "\nSalario: " + gerente.salario.setScale(2) + "\nNivel de acesso: " + gerente.NivelAcesso);
        } 
        else if (tempStr.contains("Assistente Administrativo")) {
            String nome = JOptionPane.showInputDialog(null, "Qual o nome do Assistente Administrativo?");
            String endereco = JOptionPane.showInputDialog(null, "Qual o endereço do Assistente Administrativo?");
            String sexo = JOptionPane.showInputDialog(null, "Qual o sexo do Assistente Administrativo?");
            String dataContratacao = JOptionPane.showInputDialog(null, "Qual a data de contratação do Assistente Administrativo?");
            double salario = Double.parseDouble(JOptionPane.showInputDialog(null, "Qual o salario do Assistente Administrativo?"));
            String turno = JOptionPane.showInputDialog(null, "Qual o turno do Assistente Administrativo?");
            String especializacao = JOptionPane.showInputDialog(null, "Qual a especialização do Assistente Administrativo?");
            AssistenteAdm assAdm1 = new AssistenteAdm(nome, endereco, sexo, dataContratacao, salario, especializacao, turno);
            JOptionPane.showMessageDialog(null, "Assistente Administrativo cadastrado com sucesso!");
            JOptionPane.showMessageDialog(null, "Nome: " + assAdm1.nome + "\nEndereco: " + assAdm1.endereco + "\nSexo: " + assAdm1.sexo + "\nData de Contratacao: " + assAdm1.dataContratacao + "\nSalario: R$" + assAdm1.salario + "\nTurno: " + assAdm1.turno + "\nEspecializacao: " + assAdm1.especializacao + "\nAdicional Noturno: " + assAdm1.adicionalNoturno + "\n");
        }
        else if (tempStr.contains("Assistente Tecnico")) {
            String nome = JOptionPane.showInputDialog(null, "Qual o nome do Assistente Tecnico?");
            String endereco = JOptionPane.showInputDialog(null, "Qual o endereço do Assistente Tecnico?");
            String sexo = JOptionPane.showInputDialog(null, "Qual o sexo do Assistente Tecnico?");
            String dataContratacao = JOptionPane.showInputDialog(null, "Qual a data de contratação do Assistente Tecnico?");
            double salario = Double.parseDouble(JOptionPane.showInputDialog(null, "Qual o salario do Assistente Tecnico?"));
            String especializacao = JOptionPane.showInputDialog(null, "Qual a especialização do Assistente Tecnico?");
            AssistTec assistenteTec = new AssistTec(nome, endereco, sexo, dataContratacao, salario, especializacao);
            JOptionPane.showMessageDialog(null, "Assistente Tecnico cadastrado com sucesso!");
            JOptionPane.showMessageDialog(null, "Nome: " + assistenteTec.nome + "\nEndereço: " + assistenteTec.endereco + "\nSexo: " + assistenteTec.sexo + "\nData de contratação: " + assistenteTec.dataContratacao + "\nSalario: " + assistenteTec.salario + "\nEspecialização: " + assistenteTec.especializacao);
        }
    }
}
