public class Assistente extends Funcionario{
    String especializacao;

    public Assistente(String nome, String endereco, String sexo, String dataContratacao, double salario, String especial) {
        super(nome, endereco, sexo, dataContratacao, salario);
        this.especializacao= especializacao;
    }
}
