public class AssistTec extends Assistente{
    double bonusSalarial;

    public AssistTec(String nome, String endereco, String sexo, String dataContratacao, double salario, String especializacao) {
        super(nome, endereco, sexo, dataContratacao, salario, especializacao);
        this.bonusSalarial = bonusSalarial;
    }
}