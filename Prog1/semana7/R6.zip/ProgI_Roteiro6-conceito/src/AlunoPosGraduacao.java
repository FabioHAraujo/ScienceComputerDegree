
public class AlunoPosGraduacao extends Aluno{

	public double media(double n1, double n2) {
		return (n1+n2*2)/3;
	}

}

