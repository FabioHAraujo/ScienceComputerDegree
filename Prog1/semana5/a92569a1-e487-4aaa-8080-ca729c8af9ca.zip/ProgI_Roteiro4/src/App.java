
public class App {
	
	public static void main(String args[])
	{
		
		Aluno am = new Aluno("201002", "Amanda", 25);
		Pessoa ad = new Pessoa ("Adriana Reis", 35);
		System.out.println(am.getNome());
		System.out.println(ad.getNome());
	}
	
}
