#include "ordenacao.h"

int main(void) {
    srand(time(0));
    Ordenacao ordenacao;
    ordenacao.executarOrdenacao();

    return 0;
}
