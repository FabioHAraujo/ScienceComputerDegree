Olá professor, adicionei este readme para explicar.
O arquivo 'ordenacao.h' possui todos os algoritmos feitos em C++, deve ser compilado o sorts.cpp para executar este (o senhor sabe disso, só documentando mesmo).
O arquivo 'sortsEmC.c' tem os algoritmos em C.
Para o Merge Sort usei a lógica de uma fita numa máquina de turing, pois assim consegui desenvolver com mais facilidade.

O arquivo desenvolvimento.cpp eu criei enquanto estudava, tem alguns dos meus comentários, feitos enquanto descobria como as coisas funcionavam.
Também no desenvolvimnto.cpp, tem o buscaBinaria que acabei fazendo pelo entretenimento.

Peço desculpas pelo excesso de informação, mas preferi deixar tudo bem claro.

Boa revisão dos trabalhos e bom descanso!

Atenciosamente, Fábio Henrique A.